#ifndef _VPOS_STDIO_H_
#define _VPOS_STDIO_H_

#include "printf.h"
#include "linux/string.h"

#endif //_VPOS_STDIO_H_
